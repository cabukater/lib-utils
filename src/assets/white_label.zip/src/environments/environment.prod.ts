export const environment = {
  production: true,
  ambiente: "produção"
};