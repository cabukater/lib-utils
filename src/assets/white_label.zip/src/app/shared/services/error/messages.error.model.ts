export class MessagesError {
  permission = 'Usuario ou senha invalido';
  unknown = 'Erro desconhecido contate o administrador';
  authorized = 'ok vc tem acesso';

}