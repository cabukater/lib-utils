import { Injectable } from '@angular/core';
import { MessagesError } from './messages.error.model';
import { throwError } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
@Injectable({
  providedIn: 'root'
})

export class ErrorTratService {
  constructor(
    public MessagesError: MessagesError,
    private _toastr: ToastrService
  ) { }

  checkErrors(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // client-side error
      //    errorMessage = `Error: ${error.error.message}`;
      errorMessage = 'Erro no front';
    } else {
      // server-side error
      //  errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      errorMessage = 'Erro no servidor';
    }
    // window.alert(errorMessage);
    //return throwError(errorMessage);
  }
}
