import { IMenu } from './menu.model';
import { IKeyValueLike } from '../../models/key-like-value.model'

export const FEATURE_ID_MAP: IKeyValueLike = {
  carteira: 'ROLE_PERMISSION_PORTFOLIO',
  'renda-fixa': 'ROLE_PERMISSION_INSTRUMENT',
  futuro: 'ROLE_PERMISSION_INSTRUMENT_FUTURE',
  option: 'ROLE_PERMISSION_INSTRUMENT_OPTION',
  ndf: 'ROLE_PERMISSION_INSTRUMENT_NDF',
  swap: 'ROLE_PERMISSION_INSTRUMENT_SWAP',
  preco: 'ROLE_PERMISSION_PRECIFICACAO',
  'pricing-future': 'ROLE_PERMISSION_FUTURE_PRICING',
  'pricing-derivative': 'ROLE_PERMISSION_DERIVATIVE_PRICING',
  'preco-batch': 'ROLE_PERMISSION_BULK_PRICING',
  'bulk-pricing-ot': 'ROLE_PERMISSION_BULK_PRICING_OT',
  'repurchase-agreement': 'ROLE_PERMISSION_PRICING_REPURCHASE_AGREEMENT',
  validacaobanda: 'ROLE_PERMISSION_REPORT_RANGE',
  modelo: 'ROLE_PERMISSION_MODEL',
  catalogo: 'ROLE_PERMISSION_MODEL',
  conversion: 'ROLE_PERMISSION_CONVERSIONS',
  indexes: 'ROLE_PERMISSION_INDEXING',
  curva: 'ROLE_PERMISSION_MARKET_DATA_CURVE',
  ponto: 'ROLE_PERMISSION_MARKET_DATA_SERIE',
  serie: 'ROLE_PERMISSION_MARKET_DATA_SERIE',
  'series-currency': 'ROLE_PERMISSION_MARKET_DATA_SERIES_CURRENCY',

  rate: 'ROLE_PERMISSION_MARKET_DATA_RATE',
  'market-data-index': 'ROLE_PERMISSION_MARKET_DATA_INDEX',
  portfoliocashflows: 'ROLE_PERMISSION_REPORT_PORTFOLIO',
  authorization: 'ROLE_PERMISSION_CHANGE_REQUEST',
  importacao: 'ROLE_PERMISSION_UPLOAD_FILES',
  cache: 'ROLE_PERMISSION_MAINTENANCE_CACHE',
  log: 'ROLE_PERMISSION_MAINTENANCE_LOG',
  trace: 'ROLE_PERMISSION_TRACE',
  diagnosis: 'ROLE_PERMISSION_DIAGNOSIS',
  audit: 'ROLE_PERMISSION_AUTHAUDIT',
  authaudit: 'ROLE_PERMISSION_AUDIT',
  settings: 'ROLE_PERMISSION_SETTINGS',
  bulletin: 'ROLE_PERMISSION_BULLETIN',
  'pricing-offshore-fixed-income': 'ROLE_PERMISSION_OFFSHORE_FIXED_INCOME_PRICING',
  'register-offshore-fixed-income': 'ROLE_PERMISSION_OFFSHORE_FIXED_INCOME_REGISTER'
};

export const MENU: IMenu = {
  register: {
    id: 'register',
    label: 'MENU.REGISTER',
    screens: [
      {
        key: 'carteira',
        label: 'PORTFOLIOS.MENU'
      },
      {
        key: 'renda-fixa',
        label: 'FIXED_INCOME'
      },
      {
        key: 'futuro',
        label: 'FUTURO'
      },
      {
        key: 'option',
        label: 'OPTION'
      },
      {
        key: 'ndf',
        label: 'NDF'
      },
      {
        key: 'swap',
        label: 'SWAP'
      },
      {
        key: 'bulletin',
        label: 'BULLETINS.MENU'
      },
      {
        key: 'register-offshore-fixed-income',
        label: 'OFFSHORE.FIXED_INCOME.REGISTER.MENU'
      }
    ]
  },
  calculos: {
    id: 'calculations',
    label: 'MENU.CALCULATIONS',
    screens: [
      {
        key: 'preco',
        label: 'PRICING_FIXED_INCOME.MENU'
      },
      {
        key: 'pricing-future',
        label: 'PRICING_FUTURE.MENU'
      },
      {
        key: 'pricing-derivative',
        label: 'PRICING_DERIVATIVE.MENU'
      },
      {
        key: 'pricing-offshore-fixed-income',
        label: 'OFFSHORE.FIXED_INCOME.PRICING.MENU'
      },
      {
        key: 'preco-batch',
        label: 'GROUP_PRICING.MENU'
      },
      {
        key: 'bulk-pricing-ot',
        label: 'GROUP_PRICING.MENU'
      },
      {
        key: 'repurchase-agreement',
        label: 'REPURCHASE_AGREEMENT.MENU'
      },
      {
        key: 'validacaobanda',
        label: 'PORTFOLIO_RANGES.MENU'
      },
      {
        key: 'conversion',
        label: 'CONVERSIONS.MENU'
      },
      {
        key: 'indexes',
        label: 'INDEXES.MENU'
      }
    ]
  },
  dados_mercado: {
    id: 'market_data',
    label: 'MENU.MARKET_DATA',
    screens: [
      {
        key: 'curva',
        label: 'CURVES.MENU'
      },
      {
        key: 'serie',
        label: 'SERIES.MENU'
      },
      {
        key: 'series-currency',
        label: 'SERIES_CURRENCY.MENU'
      },
      {
        key: 'market-data-index',
        label: 'INDEXES.MENU'
      },
      {
        key: 'rate',
        label: 'RATE.MENU'
      }
    ]
  },
  modelos: {
    id: 'pricingModels',
    label: 'MENU.PRICINGMODELS',
    screens: [
      {
        key: 'modelo',
        label: 'MODELS.MENU'
      },
      {
        key: 'catalogo',
        label: 'CATALOGS.MENU'
      }
    ]
  },
  reports: {
    id: 'reports',
    label: 'MENU.REPORTS',
    screens: [
      {
        key: 'portfoliocashflows',
        label: 'PORTFOLIO_CASH_FLOWS.MENU'
      }
    ]
  },
  infraestrutura: {
    id: 'infrastructure',
    label: 'MENU.INFRASTRUCTURE',
    screens: [
      {
        key: 'authorization',
        label: 'AUTORIZACAO'
      },
      {
        key: 'importacao',
        label: 'UPLOADS.MENU'
      },
      {
        key: 'cache',
        label: 'CACHES.MENU'
      },
      {
        key: 'log',
        label: 'LOGS.MENU'
      },
      {
        key: 'trace',
        label: 'TRACES.MENU'
      },
      {
        key: 'diagnosis',
        label: 'DIAGNOSES.MENU'
      },
      {
        key: 'audit',
        label: 'AUDITS.MENU'
      },
      {
        key: 'authaudit',
        label: 'AUTHAUDITS.MENU'
      }
    ]
  },
  settings: {
    id: 'settings'
  }
};
