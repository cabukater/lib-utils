export interface IScreen {
    key: string;
    label: string;
  }
  export interface IMenuDefinition {
    id: string;
    label?: string;
    screens?: Array<IScreen>;
  }
  export interface IMenu {
    [indexer: string]: IMenuDefinition;
  }
  