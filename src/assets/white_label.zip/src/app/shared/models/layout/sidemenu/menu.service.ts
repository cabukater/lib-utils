import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { IUser } from '../../user.model';
@Injectable()
export class MenuService {
  sistema: string;
  constructor(private http: HttpClient) {
  }

 /*
 Use esse serviço para receber os dados do menu (links)
 getUserMenu(): Observable<IUser> {
    let user = localStorage.getItem('username');
    let pass = localStorage.getItem('password');
    const headers = new HttpHeaders(
      {
        'Authorization': 'Basic '
          + btoa(`${user}:${pass}`)
      });
    return this.http.get<IUser>('v1/rest/user', { headers }).pipe(
      (res => {
        return res;
      })
    )
  }
}
*/
//fiz esse exemplo com os dados em mock so para visualizar os resultados  (pode remover)
  getUserMenu() {
    return this.http.get('http://localhost:3000/data')
    .pipe(res => res)
  }
  
}