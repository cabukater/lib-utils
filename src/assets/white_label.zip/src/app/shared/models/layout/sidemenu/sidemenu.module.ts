import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import{SideMenuComponent} from './sidemenu.component'
import{MenuService} from './menu.service'
import{PipesModule} from '../../pipes/pipes.module';

@NgModule({
  declarations: [
    SideMenuComponent,

  ],
  imports: [
    CommonModule,
    PipesModule
  ],
  exports:[
    SideMenuComponent,
   ],
  providers:[
    MenuService
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class SideMenuModule { }
