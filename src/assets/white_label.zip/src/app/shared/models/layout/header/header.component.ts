import { Component, EventEmitter, Output,  OnInit, ChangeDetectorRef, ViewEncapsulation } from '@angular/core';
import Swal from 'sweetalert2';
import { PageService } from '../services/page.service';
import { Router } from '@angular/router';
@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})

export class HeaderComponent{
  @Output() openMenu = new EventEmitter();
  globalTitle : string;
  openSideMenu: boolean;
  showMenu: boolean;
  usuario= localStorage.getItem('username');
theme= localStorage.getItem('colorSelected')
 constructor(
    private router: Router,
    private cd:ChangeDetectorRef,
    private PageService: PageService,
  ) { }

  clickOpenMenu(event){
    this.openSideMenu = !this.openSideMenu
    this.openMenu.emit(this.openSideMenu);
   }

   ngAfterViewChecked(){
    this.PageService.title.subscribe(
      (newTitle) => {
        this.globalTitle = newTitle;
        this.cd.detectChanges();
      }
    );
  }
}
