export class Notificacao {
    tipo: string;
    descricao: string;
    quantidade: number;
    params: string;
}
export class GrupoNotificacao {
    tituloGrupo: string;
    notificacoes: Notificacao[] = [];
}
export class StatusNotificacao {
    gruposNotificacao: GrupoNotificacao[] = [];
    tipoMaiorPrioridade: string;
    quantidadeTotalMaiorPrioridade: number;
}