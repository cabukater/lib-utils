import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { MenuService } from './menu.service';
import { IMenu, IScreen } from './menu.model';
import { Observable, EMPTY } from 'rxjs';



@Component({
  selector: 'app-sidemenu',
  templateUrl: './sidemenu.component.html',
  styleUrls: ['./sidemenu.component.scss']
})
export class SideMenuComponent implements OnInit {
  @Input() openMenu;
  oneAtATime: boolean = true;
  @Input() showMenu: boolean;
  listTeste: any;


  constructor(
    private menuService: MenuService) {}
  ngOnInit() {
    this.checkOpen();
    this.startMenu();
  }
   startMenu (){
      this.menuService.getUserMenu().subscribe(
       (data: any[])=>{
         console.log(data);
         this.listTeste = data;
         console.log(this.listTeste)
       }
      );       
  }
  checkOpen() {
    if (this.openMenu === null) {
      this.openMenu = true;
    } if (this.openMenu === true) {
      this.openMenu = true;
    } else {
      this.openMenu = true;
    }
  }
}
