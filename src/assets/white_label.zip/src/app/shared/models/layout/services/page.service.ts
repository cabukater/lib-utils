import { Injectable, EventEmitter } from '@angular/core';
@Injectable({
  providedIn: 'root'
})

export class PageService {
  title = new EventEmitter<string>();
  constructor() { }

  defineTitle(titlePage: string ){
    document.querySelector('title').textContent = titlePage;
    this.title.emit(titlePage);
  }
}
