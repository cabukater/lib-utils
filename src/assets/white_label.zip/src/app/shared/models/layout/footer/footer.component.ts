import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { LoginService } from 'src/app/login/login.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
version : string;
theme = localStorage.getItem('colorSelected');
  constructor(
    private loginService : LoginService 
  ) { }
 
  ngOnInit() {
    this.getInfo();
  }  

   getInfo(){
    this.loginService.getInfo().subscribe (
      data => {
        this.version = data.build.version

      }, error => {
       console.log(error)
      }
    )
  }
}