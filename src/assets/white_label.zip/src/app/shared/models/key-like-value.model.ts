export interface IKeyValueLike {
    [indexer: string]: string;
  }
  