export interface IUser {
    readonly name: string;
  }
  