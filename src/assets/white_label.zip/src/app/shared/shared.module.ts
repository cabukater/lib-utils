import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './layout/header/header.component';
import { FooterComponent } from './layout/footer/footer.component';
import{SideMenuModule} from './layout/sidemenu/sidemenu.module'
import{MapsAngularComponentsModule, ColorModule, ButtonsModule, NotificationsModule} from 'maps-angular-components';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDropdownModule } from 'ngx-bootstrap';
import { PipesModule } from './pipes/pipes.module';
@NgModule({
  declarations: [
    HeaderComponent,
    FooterComponent
  ],
  imports: [
    CommonModule,
    SideMenuModule,
    ButtonsModule,
    MapsAngularComponentsModule, 
    BrowserAnimationsModule,
    NotificationsModule,
    PipesModule,
    BsDropdownModule.forRoot(),
    ColorModule
  ],
  exports:[
    HeaderComponent,
    FooterComponent
  ]
})
export class SharedModule { }
