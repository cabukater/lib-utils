import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IconsPipe } from './icons.pipe';
import{ReplacePipe} from './replace.pipe'

@NgModule({
  declarations: [
    IconsPipe,
    ReplacePipe
  ],
  imports: [
    CommonModule
  ],
  exports:[
    ReplacePipe,
    IconsPipe]
})
export class PipesModule { }
