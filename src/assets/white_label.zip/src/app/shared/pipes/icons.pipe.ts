import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'icon'
})

export class IconsPipe implements PipeTransform {
 //icons disponiveis em https://fontawesome.com/icons?d=gallery
  transform(value: any, ...args: any[]): any {
    switch (value) {
      case "one": //nome do item pai
        return "fas fa-bell"; //classe da fonte do menu
      case "two":
        return "far fa-thumbs-up";
      default:
        break;
    }
  }

}
