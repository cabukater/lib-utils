import { IconsPipe } from './icons.pipe';

describe('IconsPipe', () => {
  it('create an instance', () => {
    const pipe = new IconsPipe();
    expect(pipe).toBeTruthy();
  });
});
