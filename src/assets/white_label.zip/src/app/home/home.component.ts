import { Component, OnInit } from '@angular/core';
import { PageService } from '../shared/layout/services/page.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})

export class HomeComponent implements OnInit {
  headerFooter: boolean;
  
  title : 'home';
  constructor(
    private pageService : PageService
  ) { }

  ngOnInit() {
    this.headerFooter = true,
    this.pageService.defineTitle('Home')

  }

}
