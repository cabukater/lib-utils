import { Component, Input } from '@angular/core';
import { LoginService } from './login/login.service';
import { AuthService } from './login/auth.service';
import { ColorService } from 'maps-angular-components';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'front-end';
  theme = localStorage.getItem('colorSelected');
  @Input('headerFooter') headerFooter: boolean;
  @Input() openMenuOne;
  showMenu: boolean = false;
  version: string;
  constructor(
    public colorService: ColorService,
    private loginService: LoginService,
    private authService: AuthService) {
    this.authService.showMenuEmitter.subscribe(
      show => this.showMenu = show
    )
    this.getUser();
  }

  showEvent(event) {
    this.openMenuOne = event;
  }

  getUser() {
    this.loginService.getUser().subscribe(
      data => {
        const user = true
        this.authService.goToLogin(user)
      },
      error => {
        console.log(error)
      })
  }
}

