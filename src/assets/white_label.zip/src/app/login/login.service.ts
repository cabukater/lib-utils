import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';
@Injectable()
export class LoginService {
    footerService

    private httpOptions = {
        headers: new HttpHeaders({
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept-Encoding': 'gzip, deflate'
        },
        )
    };

    private readonly url = `/v1/login`;

    constructor(
        private route: Router,
        private authService: AuthService,
        private http: HttpClient) { }

    login(username, password) {
        localStorage.setItem('password', password);
        localStorage.setItem('username', username)
        var formData: any = new FormData();
        formData.append("username", username);
        formData.append("password", password);
        return this.http.post(this.url, formData).subscribe(
            (response: Response) => {
            }, (err) => {
                console.log('Error: ' + err);
            }
        )
    }

    getUser(): Observable<any> {
        let user = localStorage.getItem('username');
        let pass = localStorage.getItem('password');
        const headers = new HttpHeaders(
            {
                'Authorization': 'Basic '
                    + btoa(`${user}:${pass}`)
            });
        return this.http.get('http://localhost:3004/v1', { headers }).pipe(
            (res => {
                return res;
            })
        )
    }

    getInfo(): Observable<any> {
        let user = localStorage.getItem('username');
        let pass = localStorage.getItem('password');
        const headers = new HttpHeaders(
            {
                'Authorization': 'Basic '
                    + btoa(`${user}:${pass}`)
            });
        return this.http.get('v1/management/info', { headers }).pipe(
            (res => {
                return res;
            })
        )
    }

    logout() {
        localStorage.removeItem('password');
    }
}
