import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
@Injectable()
export class AuthService {
    private headers = new HttpHeaders();
    private url: string;
    private userAuthenticated: boolean = false;
    showMenuEmitter = new EventEmitter<boolean>();

    constructor(
        private route: Router,
        private http: HttpClient) { }

    logout() {
        return this.http.get(`${this.url}/logout`);
    }

    goToLogin(user) {
        const token = sessionStorage.getItem('username');
        const password = sessionStorage.getItem('password');

        if (user === true) {
            console.log('token');
            this.userAuthenticated = true;
            this.showMenuEmitter.emit(true);
            this.route.navigate(['/home'])
        } else {
            this.userAuthenticated = false;
            this.showMenuEmitter.emit(false);
        }}

    isAuthenticated() {
        return this.userAuthenticated
    }

}