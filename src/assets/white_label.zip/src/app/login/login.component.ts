import { Component, OnInit, Pipe } from '@angular/core';
import { LoginService } from './login.service';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from './auth.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  headerFooter: boolean;
  form: FormGroup;
  formSubmitAttempt: boolean;
  usuario: string;
  mensagemErro = '';
  constructor(
    private router: Router,
    private authService: AuthService,
    private loginService: LoginService,
    private formBuilder: FormBuilder) { }
  ngOnInit() {
    this.formConstr();
    this.headerFooter = false;
  }
  formConstr() {
    this.form = new FormGroup({
      username: new FormControl(),
      password: new FormControl()
    });
  }
  sendForm(form) {
    const user = this.form.get('username').value;
    const password = this.form.get('password').value
    this.loginService.login(user, password)
    this.getUser();
  }
  getUser() {
    this.loginService.getUser().subscribe(
      data => {
        const user = true
        this.authService.goToLogin(user)
      },
      error => { }
    )
  }
}
